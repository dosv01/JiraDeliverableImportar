﻿# node-csv-mongodb

Repositório criado para demonstrar como nós podemos importar dados de um arquivo .csv para uma base de dados mongoDB.

link do artigo demonstrando cada um dos passos do código desse repositório: [Node - CSV - Mongo](https://programadriano.medium.com/node-js-importando-dados-de-um-arquivo-csv-para-o-mongodb-1156b0a05541)

## Desenvolvimento

Para rodar o projeto é necessário adicionar uma string de conexão no arquivo ./config/db.js. Com os dados de acesso ao banco OK, basta executar o comando `node index.js` para importar os dados do arquivo battles.csv que está na raiz do projeto.
